package org.example.Controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.example.Service.CalculatorService;
import org.example.entity.Calculator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@Controller
@Slf4j
@ResponseBody
public class controller {
    @Autowired
    private CalculatorService calculatorService;

    long value=0;
@RequestMapping ("/give")
    public void info(@RequestParam("formual") String formual, @RequestParam("answer") String answer){
     log.info("公式为：{}",formual);
     log.info("答案为{}",answer);
    Calculator calculator=new Calculator();
    calculator.setFormula(formual);
    calculator.setAnswer(answer);
    log.info(calculator.toString());
    calculatorService.save(calculator);
    log.info(calculator.toString());
    value=calculator.getId();
}
@RequestMapping("/info")
@Transactional
    public String Search() throws JsonProcessingException {
    if(value==0){
        Calculator calculator=calculatorService.getById(1);
        String msg=calculator.getFormula();
        ObjectMapper objectMapper=new ObjectMapper();
        String str=objectMapper.writeValueAsString(msg);
        return str;
    }else{
    Calculator calculator=calculatorService.getById(value);
    log.info(calculator.toString());
    String msg=calculator.getFormula();
        ObjectMapper objectMapper=new ObjectMapper();
        String str=objectMapper.writeValueAsString(msg);
        return str;
    }
}

}
