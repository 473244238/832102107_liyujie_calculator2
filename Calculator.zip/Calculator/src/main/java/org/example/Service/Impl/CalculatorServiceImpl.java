package org.example.Service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.example.Service.CalculatorService;
import org.example.entity.Calculator;
import org.example.mapper.CalculatorMapper;
import org.springframework.stereotype.Service;

@Service
public class CalculatorServiceImpl extends ServiceImpl<CalculatorMapper, Calculator> implements CalculatorService {
}
