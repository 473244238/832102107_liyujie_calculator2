package org.example.Service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.entity.Calculator;

public interface CalculatorService extends IService<Calculator> {
}
