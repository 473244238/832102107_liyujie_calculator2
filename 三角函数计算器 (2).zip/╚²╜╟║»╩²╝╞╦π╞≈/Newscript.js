const display=document.querySelector('#display');
const buttons=document.querySelectorAll('button')
buttons.forEach((item)=>{
    item.onclick=() =>{
        if(item.id=='clear' ){
            display.innerText="";
        }else if(item.id=='backspace'){
            let string=display.innerText.toString();

            display.innerText=string.substr(0,string.length-1);
        }else if(display.innerText!=''&&item.id=='equal'){
            const expression = display.innerText;
            const modifiedExpression = expression.replace(/%/g, '%');
            display.innerText=eval(modifiedExpression);
            ajax(expression,eval(modifiedExpression));
        }else if(display.innerText==""&&item.id=='equal'){
            display.innerText='Empty!';
            setTimeout(()=>(display.innerText=''),2000);
        }else if(item.id=='sin'){
            const expression = display.innerText;
            try {

                const result = eval(expression);
                const sinValue = Math.sin(result);
                display.innerText = `sin(${expression}) = ${sinValue.toFixed(2)}`;
                ajax(display.innerText,sinValue.toFixed(2))
            } catch (error) {
                display.innerText = 'Error';
            }
            
          
            setTimeout(()=>(display.innerText=''),3000);
         
        }else if(item.id=='cos'){
            const expression=display.innerText;
            try {
                const result = eval(expression);
                const cosValue = Math.cos(result);
                display.innerText = `cos(${expression}) = ${cosValue.toFixed(2)}`;
                ajax(display.innerText,cosValue.toFixed(2));
            } catch (error) {
                display.innerText = 'Error';
            }
            setTimeout(()=>(display.innerText=''),3000);
        }else if(item.id=='tan'){
            const expression=display.innerText;
            try {
                const result = eval(expression);
                const tanValue = Math.tan(result);
                display.innerText = `tan(${expression}) = ${tanValue.toFixed(2)}`;
                ajax(display.innerText,tanValue.toFixed(2))
            } catch (error) {
                display.innerText = 'Error';
            }
            setTimeout(()=>(display.innerText=''),3000);
        }else if(item.id=='sqrt'){
            const expression=display.innerText;
            const result=eval(expression);
            const sq=Math.sqrt(result);
            display.innerText=sq.toFixed(2);
        }else if(item.id=="PI"){
            display.innerText+=Math.PI;
        }else if(item.id=="search"){

                let xhr;
                if(window.XMLHttpRequest){
                    xhr=new XMLHttpRequest();
                }else{
                    xhr=new ActiveXObject("Microsoft.XMLHTTP")
                }
                
                xhr.timeout=4000;
                xhr.ontimeout=function(){
                    console.log('抱歉，超时了');
                }
                
                xhr.open('POST',"http://localhost:8080/info")
                
                xhr.onreadystatechange=function(){
                    if(xhr.status==200){
                        console.log(xhr.responseText);
                        display.innerText=search;
                    
                    }
                   
                
                }
                
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.send();
                
            setTimeout(()=>(display.innerText=''),3000);
        }
        else{
            display.innerText+=item.id;
        }
    }
})
const themeToggleBtn=document.querySelector('.theme-toggler');
const calculator=document.querySelector('.calculator');
const toggleIcon=document.querySelector(".toggler-icon");
let isDark=true;
themeToggleBtn.onclick=()=>{
    calculator.classList.toggle('dark');
    themeToggleBtn.classList.toggle('active');
    isDark=!isDark;
}

function ajax(data1,data2){
let xhr;
if(window.XMLHttpRequest){
    xhr=new XMLHttpRequest();
}else{
    xhr=new ActiveXObject("Microsoft.XMLHTTP")
}

xhr.timeout=4000;
xhr.ontimeout=function(){
    console.log('抱歉，超时了');
}

xhr.open('POST',"http://localhost:8080/give")

xhr.onreadystatechange=function(){
    if(xhr.readyState==4&&xhr.status==200){
        console.log(xhr.responsText);
    
    }
   

}
let formual = encodeURIComponent(data1);  // 对数据进行编码
let answer = encodeURIComponent(data2);   // 对数据进行编码
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xhr.send('formual='+formual+'&answer='+answer);
}
